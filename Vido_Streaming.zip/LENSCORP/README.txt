# Video Streaming Service

This project is a C++ application that streams videos from YouTube using `yt-dlp` and serves them over HTTP. The application is packaged inside a Docker container for easy deployment.

## Prerequisites

- Ensure you have [Docker](https://www.docker.com/get-started) installed on your machine.

## Building the Docker Image

1. **Navigate to the Project Directory**:
   Open your terminal and navigate to the directory containing the `Dockerfile` and `video_stream.cpp`:

   ```bash
   cd path/to/LENSCORP
   ```

2. **Build the Docker Image**:
   Run the following command to build the Docker image:

   ```bash
   docker build -t video_stream_service .
   ```

   This command creates a Docker image named `video_stream_service` from the Dockerfile.

## Running the Docker Container

1. **Run the Container**:
   You can run the Docker container with the following command:

   ```bash
   docker run -p 8080:8080 video_stream_service
   ```

   - This command maps port `8080` of your host machine to port `8080` of the container, allowing you to access the video streaming service.

2. **Access the Streaming Service**:
   Open your web browser and navigate to:

   ```
   http://localhost:8080
   ```

## Changing the YouTube URL

If you want to change the YouTube URL from which the video is streamed, you can override the default URL by running the container with a new URL:

```bash
docker run -p 8080:8080 video_stream_service "https://your_new_video_url_here"
```

## Changing the Port

To change the port on which the service runs, modify the `EXPOSE` line in the Dockerfile to your desired port (e.g., `EXPOSE 8081`) and rebuild the image. 

Then, run the container with the new port mapping:

```bash
docker run -p your_desired_port:8080 video_stream_service
```

### Example:

If you want to run the service on port `8081`, modify the Dockerfile:

```dockerfile
EXPOSE 8081
```

Rebuild the image:

```bash
docker build -t video_stream_service .
```

Run the container:

```bash
docker run -p 8081:8080 video_stream_service
```

## Error Handling

- **YouTube Video URL Issues**:
  - If the URL is invalid or the video is unavailable, the application will log an error and terminate.
  
- **Dependency Errors**:
  - Ensure that all dependencies are properly installed. If you encounter issues with `yt-dlp`, check if the required Python packages are available in the Docker container.

- **Port Already in Use**:
  - If you encounter an error stating that the port is already in use, change the host port in the `docker run` command to a different number.

## Conclusion

This Dockerized C++ application allows for efficient video streaming from YouTube. Modify the URL and port settings as needed to suit your requirements. If you face any issues, please refer to the error handling section for guidance.
