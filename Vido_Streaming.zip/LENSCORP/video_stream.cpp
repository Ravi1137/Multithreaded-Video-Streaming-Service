#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <queue>
#include <fstream>
#include <chrono>
#include <boost/beast/core.hpp>
#include <boost/beast/http.hpp>
#include <boost/asio.hpp>
#include <iomanip>  // For formatting date and time
#include <ctime>    // For converting time

// Namespaces for Boost.Beast and Asio
namespace beast = boost::beast;
namespace http = beast::http;
namespace net = boost::asio;
using tcp = net::ip::tcp;

// Global variables
std::mutex mtx;
std::condition_variable cv;
bool finishedDownloading = false;

// Function to log messages with proper date and time
void log(const std::string &message) {
    auto now = std::chrono::system_clock::now();
    std::time_t now_time = std::chrono::system_clock::to_time_t(now);
    std::tm localTime = *std::localtime(&now_time);

    std::cout << "[" << std::put_time(&localTime, "%Y-%m-%d %H:%M:%S") << "] " << message << std::endl;

    // Log to file (append mode)
    std::ofstream logFile("application_log.txt", std::ios::app);
    if (logFile.is_open()) {
        logFile << "[" << std::put_time(&localTime, "%Y-%m-%d %H:%M:%S") << "] " << message << std::endl;
        logFile.close();
    } else {
        std::cerr << "Error opening log file." << std::endl;
    }
}

// Function to execute yt-dlp and download video to a file
void downloadVideo(const std::string &url) {
    log("Starting video download from: " + url);
    std::string command = "yt-dlp -f 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best' -o video.mp4 " + url;
    log("Downloading video using yt-dlp: " + command);

    // Execute command
    int result = std::system(command.c_str());

    if (result == 0) {
        log("Video downloaded successfully.");
    } else {
        log("Error downloading video. Exit code: " + std::to_string(result));
    }

    finishedDownloading = true; 
    cv.notify_all();  
}

// Function to monitor and log FPS during video streaming
void monitorFPS(int &frameCount, std::chrono::steady_clock::time_point &lastFrameTime, std::size_t bytesSent) {
    const int minFPS = 30;
    const double bytesPerFrame = 8192;  // Estimate bytes per frame (for simplicity, assuming one chunk ~ 8 KB)
    
    frameCount++;  // Increment the frame count (corresponds to chunk sent)
    auto now = std::chrono::steady_clock::now();
    std::chrono::duration<double> elapsed = now - lastFrameTime;
    double fps = frameCount / elapsed.count();  // FPS calculated as chunks sent per second

    log("FPS: " + std::to_string(fps) + " | Bytes Sent: " + std::to_string(bytesSent) + " bytes");

    // Logging a warning if FPS drops below 30
    if (fps < minFPS) {
        log("Warning: FPS dropped below " + std::to_string(minFPS) + "!");
    }

    lastFrameTime = now; 
}

// Function to stream video to a connected client via HTTP with FPS monitoring
void streamVideo(tcp::socket socket) {
    log("New client connected.");
    try {
        // Check if the video file is in MP4 format
        std::string videoFileName = "video.mp4";
        if (videoFileName.substr(videoFileName.find_last_of(".") + 1) != "mp4") {
            log("Error: Unsupported video format. Only MP4 is supported.");
            return;
        }

        beast::error_code ec;
        http::file_body::value_type body;
        body.open(videoFileName.c_str(), beast::file_mode::scan, ec);
        if (ec) {
            log("Failed to open video file: " + ec.message());
            return;
        }

        log("Streaming video to client.");

        http::response<http::file_body> res{http::status::ok, 11};
        res.set(http::field::server, "Boost.Beast");
        res.set(http::field::content_type, "video/mp4");
        res.content_length(body.size());
        res.body() = std::move(body);

        // Variables for FPS monitoring
        int frameCount = 0;
        auto lastFrameTime = std::chrono::steady_clock::now();

        http::serializer<false, http::file_body> sr{res};
        std::size_t totalBytesSent = 0;
        
        while (!sr.is_done()) {
            std::size_t bytesSent = http::write(socket, sr, ec);
            if (ec) {
                log("Error during video streaming: " + ec.message());
                return;
            }

            totalBytesSent += bytesSent;

            // Monitor FPS for each chunk sent (we treat each chunk sent as a "frame")
            monitorFPS(frameCount, lastFrameTime, totalBytesSent);
        }

        log("Video stream sent to client.");
        log("Stream completed for client.");
    } catch (const std::exception &e) {
        log("Error in streamVideo: " + std::string(e.what()));
    }
}



// Function to start the HTTP server and handle incoming client connections
void startHTTPServer(unsigned short port) {
    log("Starting HTTP server on port " + std::to_string(port));
    net::io_context ioc{1};
    tcp::acceptor acceptor{ioc, {tcp::v4(), port}};

    while (true) {
        try {
            tcp::socket socket{ioc};
            acceptor.accept(socket);

            // Pass the socket by value to the thread
            std::thread(streamVideo, std::move(socket)).detach();
        } catch (const boost::system::system_error &e) {
            log("Error accepting connection: " + std::string(e.what()));
        }
    }
}

// Main function
int main(int argc, char* argv[]) {
    try {
        // Check if URL is provided
        if (argc < 2) {
            log("Usage: " + std::string(argv[0]) + " <YouTube Video URL>");
            return 1;
        }
        // URL of the YouTube video
        std::string videoURL = argv[1];
        log("Received video URL: " + videoURL);

        // Start the download thread
        std::thread downloadThread(downloadVideo, videoURL);

        // Start the HTTP server on port 8080
        std::thread serverThread(startHTTPServer, 8080);

        log("All threads started successfully.");

        // Wait for all threads to complete
        downloadThread.join();
        serverThread.join();
        
    } catch (const std::exception &e) {
        log("Error in main: " + std::string(e.what()));
        return 1;
    }

    log("Application exiting.");
    return 0;
}
